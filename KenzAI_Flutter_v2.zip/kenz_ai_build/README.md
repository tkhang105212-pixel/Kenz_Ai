# Kenz AI v2

App chat AI (code + phân tích ảnh/tệp) viết bằng Flutter. Hỗ trợ **Claude, Grok, OpenAI, OpenRouter, Groq, Gemini** và server tùy chỉnh.

## Có gì mới ở v2
- **Kenz SDK** (`lib/sdk/kenz_sdk.dart`): client đa nhà cung cấp, streaming SSE, tự retry (429/5xx), hủy giữa chừng. Dùng độc lập được.
- **Claude** gọi bằng API Anthropic gốc (ảnh + PDF đọc trực tiếp), Grok/OpenAI/... qua API tương thích OpenAI.
- **Phân tích tệp thông minh** (`lib/services/file_analyzer.dart`), chạy ở isolate nền:
  - Code/log/text: đếm dòng, outline hàm/class, gom dòng lỗi. **Tệp nhiều GB được quét bằng stream** (không nạp vào RAM), chỉ gửi đầu/cuối + dòng lỗi.
  - CSV/TSV: schema + thống kê (min/max/TB, giá trị phân loại, ô thiếu) trên toàn bộ file.
  - JSON: cấu trúc key/kiểu/độ dài mảng.
  - DOCX / XLSX / PPTX: trích văn bản, bảng, slide.
  - ZIP: cây thư mục + nội dung các tệp quan trọng (README, manifest, entrypoint...).
  - PDF: Claude đọc trực tiếp (cả hình/bảng); provider khác dùng trích văn bản cơ bản.
  - Nhị phân lạ: hex header + chuỗi đọc được.
- Đính kèm nhiều tệp/ảnh một lúc (tối đa 10), gợi ý nhanh "Tóm tắt / Tìm lỗi / ...".
- Trả lời **streaming**, nút **Dừng**, **Thử lại**, copy từng code block.
- Chế độ **Deep**, đổi provider/model nhanh, nút **Kiểm tra kết nối**.
- Lưu hội thoại vào file (còn sau khi tắt app), nhớ cả nội dung tệp đã đọc.
- Giới hạn đã tăng: Gradle heap **4 GB**, `largeHeap`, trả lời tối đa 32k token, ngân sách tệp tới 1.5M ký tự, timeout dài hơn.

## Dùng SDK riêng
```dart
final client = KenzClient(KenzOptions(
  type: ProviderType.anthropic,
  baseUrl: 'https://api.anthropic.com/v1',
  apiKey: 'sk-ant-...',
  model: 'claude-sonnet-5-5',
));
await for (final chunk in client.stream([ChatTurn('user', 'Xin chào')])) {
  print(chunk);
}
```

## Yêu cầu
- Flutter 3.24+ (Dart >= 3.4), JDK 17, Android SDK

## Build APK
```bash
./build_apk.sh          # release
./build_apk.sh split    # mỗi ABI 1 APK (nhẹ hơn)
./build_apk.sh debug
```
Hoặc build online: đẩy lên GitHub > Actions > **Build APK** > Run workflow.

## Lưu ý
- Chọn tệp rất lớn trên Android: `file_picker` sao chép tệp vào bộ nhớ đệm của app nên cần đủ dung lượng trống (bằng cỡ tệp) và mất một lúc.
- Video chưa được model xem trực tiếp; app sẽ nhắc gửi khung hình quan trọng.
- Claude dùng temperature mặc định của model.
- Chưa test trên máy: hãy chạy `flutter pub get && flutter analyze` trước khi build.
