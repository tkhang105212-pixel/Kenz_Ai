@echo off
cd /d "%~dp0"
set MODE=%1
if "%MODE%"=="" set MODE=release

call flutter pub get || goto :err
if "%MODE%"=="debug" (
  call flutter build apk --debug || goto :err
) else if "%MODE%"=="split" (
  call flutter build apk --release --split-per-abi || goto :err
) else (
  call flutter build apk --release || goto :err
)
echo.
echo APK nam o: build\app\outputs\flutter-apk\
dir /b build\app\outputs\flutter-apk\*.apk
exit /b 0
:err
echo Build that bai.
exit /b 1
