import 'package:flutter/material.dart';
import '../sdk/kenz_sdk.dart';
import '../services/ai_service.dart';
import '../services/settings_store.dart';
import '../utils/theme.dart';

double _c(double v, double lo, double hi) => v < lo ? lo : (v > hi ? hi : v);

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  AppSettings _s = AppSettings();
  bool _loaded = false;
  bool _obscure = true;
  bool _testing = false;
  final _key = TextEditingController();
  final _url = TextEditingController();
  final _model = TextEditingController();
  final _prompt = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final s = await AppSettings.load();
    setState(() {
      _s = s;
      _prompt.text = s.customPrompt;
      _syncIn();
      _loaded = true;
    });
  }

  void _syncIn() {
    _key.text = _s.keys[_s.providerId] ?? '';
    _url.text = _s.baseUrls[_s.providerId] ?? _s.preset.baseUrl;
    _model.text = _s.models[_s.providerId] ?? _s.preset.defaultModel;
  }

  void _syncOut() {
    final id = _s.providerId;
    _s.keys[id] = _key.text.trim();
    _s.baseUrls[id] = _url.text.trim();
    _s.models[id] = _model.text.trim();
    _s.customPrompt = _prompt.text;
  }

  void _selectProvider(String id) {
    setState(() {
      _syncOut();
      _s.providerId = id;
      _syncIn();
    });
  }

  Future<void> _save() async {
    _syncOut();
    await _s.save();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Đã lưu cài đặt!'),
        backgroundColor: KenzTheme.primaryBlue,
        behavior: SnackBarBehavior.floating,
      ),
    );
    Navigator.pop(context);
  }

  Future<void> _test() async {
    _syncOut();
    setState(() => _testing = true);
    final msg = await AIService().test(_s);
    if (!mounted) return;
    setState(() => _testing = false);
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: KenzTheme.cardBg,
        title: const Text('Kiểm tra kết nối'),
        content: SingleChildScrollView(child: Text(msg)),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Đóng'))],
      ),
    );
  }

  Widget _label(String t) => Padding(
        padding: const EdgeInsets.only(top: 18, bottom: 8),
        child: Text(t, style: const TextStyle(color: KenzTheme.textPrimary, fontWeight: FontWeight.w600)),
      );

  Widget _hint(String t) => Padding(
        padding: const EdgeInsets.only(top: 6),
        child: Text(t, style: const TextStyle(color: KenzTheme.textSecondary, fontSize: 12)),
      );

  @override
  Widget build(BuildContext context) {
    if (!_loaded) {
      return Scaffold(
        appBar: AppBar(title: const Text('Cài đặt Kenz AI')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }
    final p = _s.preset;
    return Scaffold(
      appBar: AppBar(title: const Text('Cài đặt Kenz AI')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _label('Nhà cung cấp AI'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final pr in KenzProviders.all)
                ChoiceChip(
                  label: Text(pr.name),
                  selected: pr.id == _s.providerId,
                  onSelected: (_) => _selectProvider(pr.id),
                ),
            ],
          ),
          _label('API Key (${p.name})'),
          TextField(
            controller: _key,
            obscureText: _obscure,
            style: const TextStyle(color: KenzTheme.textPrimary),
            decoration: InputDecoration(
              hintText: p.keyHint,
              suffixIcon: IconButton(
                icon: Icon(_obscure ? Icons.visibility : Icons.visibility_off, color: KenzTheme.textSecondary),
                onPressed: () => setState(() => _obscure = !_obscure),
              ),
            ),
          ),
          _hint('Mỗi nhà cung cấp lưu key riêng, chỉ nằm trên máy bạn.'),
          _label('Model'),
          TextField(
            controller: _model,
            style: const TextStyle(color: KenzTheme.textPrimary),
            decoration: InputDecoration(hintText: p.defaultModel.isEmpty ? 'tên model' : p.defaultModel),
          ),
          if (p.models.isNotEmpty) ...[
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                for (final m in p.models)
                  ActionChip(label: Text(m, style: const TextStyle(fontSize: 12)), onPressed: () => setState(() => _model.text = m)),
              ],
            ),
          ],
          _label('Base URL'),
          TextField(
            controller: _url,
            style: const TextStyle(color: KenzTheme.textPrimary),
            decoration: InputDecoration(hintText: p.baseUrl),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _testing ? null : _test,
              icon: _testing
                  ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.wifi_tethering),
              label: const Text('Kiểm tra kết nối'),
            ),
          ),
          const Divider(height: 36),
          _label('Độ dài trả lời tối đa: ${_s.maxTokens} token'),
          Slider(
            value: _c(_s.maxTokens.toDouble(), 1024, 32768),
            min: 1024,
            max: 32768,
            divisions: 31,
            onChanged: (v) => setState(() => _s.maxTokens = v.round()),
          ),
          _label('Ngân sách nội dung tệp: ${(_s.charBudget / 1000).round()}k ký tự (~${(_s.charBudget / 4000).round()}k token)'),
          Slider(
            value: _c(_s.charBudget.toDouble(), 100000, 1500000),
            min: 100000,
            max: 1500000,
            divisions: 14,
            onChanged: (v) => setState(() => _s.charBudget = v.round()),
          ),
          _hint('Tổng lượng chữ trích từ tệp đưa vào 1 tin nhắn. Tăng nếu model có context lớn; giảm nếu gặp lỗi quá dài.'),
          _label('Nhớ ${_s.historyTurns} tin nhắn gần nhất'),
          Slider(
            value: _c(_s.historyTurns.toDouble(), 4, 100),
            min: 4,
            max: 100,
            divisions: 24,
            onChanged: (v) => setState(() => _s.historyTurns = v.round()),
          ),
          _label('Temperature: ${_s.temperature.toStringAsFixed(1)}'),
          Slider(
            value: _c(_s.temperature, 0, 1.5),
            min: 0,
            max: 1.5,
            divisions: 15,
            onChanged: (v) => setState(() => _s.temperature = v),
          ),
          _hint('Không áp dụng cho Claude (dùng mặc định của model).'),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Chế độ Deep (suy luận kỹ hơn)'),
            subtitle: const Text('Model tự rà soát lỗi và cân nhắc phương án trước khi trả lời'),
            value: _s.deepMode,
            onChanged: (v) => setState(() => _s.deepMode = v),
          ),
          _label('Chỉ dẫn riêng (system prompt thêm)'),
          TextField(
            controller: _prompt,
            maxLines: 4,
            style: const TextStyle(color: KenzTheme.textPrimary),
            decoration: const InputDecoration(hintText: 'VD: Luôn dùng Kotlin + Jetpack Compose, trả lời ngắn.'),
          ),
          const SizedBox(height: 28),
          SizedBox(
            height: 50,
            child: ElevatedButton(
              onPressed: _save,
              child: const Text('Lưu cài đặt', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _key.dispose();
    _url.dispose();
    _model.dispose();
    _prompt.dispose();
    super.dispose();
  }
}
