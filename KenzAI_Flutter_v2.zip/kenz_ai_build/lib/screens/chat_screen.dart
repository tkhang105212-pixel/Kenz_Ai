import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';
import '../models/attachment.dart';
import '../models/message.dart';
import '../sdk/kenz_sdk.dart';
import '../services/ai_service.dart';
import '../services/chat_store.dart';
import '../services/file_analyzer.dart';
import '../services/settings_store.dart';
import '../utils/theme.dart';
import '../widgets/input_bar.dart';
import '../widgets/message_bubble.dart';
import 'settings_screen.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  static const _maxAttachments = 10;

  final List<ChatMessage> _messages = [];
  final List<Attachment> _pending = [];
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scroll = ScrollController();
  final AIService _ai = AIService();
  final Uuid _uuid = const Uuid();
  final ImagePicker _picker = ImagePicker();

  AppSettings _settings = AppSettings();
  bool _busy = false;
  bool _cancelled = false;
  bool _stick = true;
  String _status = '';

  @override
  void initState() {
    super.initState();
    _scroll.addListener(() {
      if (!_scroll.hasClients) return;
      _stick = _scroll.position.pixels >= _scroll.position.maxScrollExtent - 80;
    });
    _init();
  }

  Future<void> _init() async {
    try {
      final s = await AppSettings.load();
      final saved = await ChatStore.load();
      if (!mounted) return;
      setState(() {
        _settings = s;
        _messages.addAll(saved);
      });
      _scrollToBottom(jump: true);
    } catch (_) {
      // Không có plugin lưu trữ (vd: môi trường test) -> dùng cấu hình mặc định.
    }
  }

  // ---------------------------------------------------------------- picking

  Future<void> _addPath(String p) async {
    if (_pending.length >= _maxAttachments) {
      _snack('Tối đa $_maxAttachments tệp mỗi tin nhắn');
      return;
    }
    if (_pending.any((a) => a.path == p)) return;
    try {
      final a = await Attachment.fromPath(p);
      if (mounted) setState(() => _pending.add(a));
    } catch (e) {
      _snack('Không đọc được tệp: $e');
    }
  }

  Future<void> _pickImages() async {
    try {
      final imgs = await _picker.pickMultiImage(imageQuality: 85, maxWidth: 1920);
      for (final x in imgs) {
        await _addPath(x.path);
      }
    } catch (e) {
      _snack('Không thể chọn ảnh: $e');
    }
  }

  Future<void> _takePhoto() async {
    try {
      final x = await _picker.pickImage(source: ImageSource.camera, imageQuality: 85, maxWidth: 1920);
      if (x != null) await _addPath(x.path);
    } catch (e) {
      _snack('Không thể chụp ảnh: $e');
    }
  }

  Future<void> _pickVideo() async {
    try {
      final r = await FilePicker.platform.pickFiles(type: FileType.video, withData: false);
      if (r != null && r.files.single.path != null) await _addPath(r.files.single.path!);
    } catch (e) {
      _snack('Không thể chọn video: $e');
    }
  }

  Future<void> _pickFiles() async {
    try {
      final r = await FilePicker.platform.pickFiles(
        type: FileType.any,
        allowMultiple: true,
        withData: false,
      );
      if (r == null) return;
      for (final f in r.files) {
        if (f.path != null) await _addPath(f.path!);
      }
    } catch (e) {
      _snack('Không thể chọn tệp: $e');
    }
  }

  // ---------------------------------------------------------------- sending

  Future<void> _send({String? override}) async {
    final text = (override ?? _controller.text).trim();
    if (text.isEmpty && _pending.isEmpty) return;
    if (_busy) return;
    if (_settings.apiKey.isEmpty && _settings.providerId != 'custom') {
      _snack('Chưa có API key cho ${_settings.preset.name}', action: 'Cài đặt', onAction: _openSettings);
      return;
    }

    var atts = List<Attachment>.from(_pending);
    final hasFiles = atts.any((a) => a.kind != AttachmentKind.image);
    setState(() {
      _busy = true;
      _cancelled = false;
      _status = hasFiles ? 'Đang đọc & phân tích tệp...' : '';
    });

    String? ctx;
    if (hasFiles) {
      try {
        final r = await FileAnalyzer.analyze(
          atts,
          providerNativePdf: _settings.preset.nativePdf,
          totalCharBudget: _settings.charBudget,
        );
        ctx = r.context.isEmpty ? null : r.context;
        atts = atts
            .map((a) => r.nativePdfPaths.contains(a.path) ? a.copyWith(nativePdf: true) : a)
            .toList();
      } catch (e) {
        ctx = '[Lỗi khi phân tích tệp: $e]';
      }
    }

    final hasImg = atts.any((a) => a.kind == AttachmentKind.image);
    final content = text.isNotEmpty
        ? text
        : (hasFiles
            ? 'Hãy phân tích kỹ các tệp đính kèm: tóm tắt nội dung, điểm đáng chú ý, vấn đề (nếu có) và đề xuất.'
            : (hasImg ? 'Hãy phân tích ảnh này giúp tôi' : ''));

    setState(() {
      _messages.add(ChatMessage(
        id: _uuid.v4(),
        role: MessageRole.user,
        content: content,
        attachments: atts,
        fileContext: ctx,
      ));
      _pending.clear();
      _controller.clear();
    });
    await _generate();
  }

  Future<void> _generate() async {
    final replyId = _uuid.v4();
    setState(() {
      _busy = true;
      _cancelled = false;
      _status = '';
      _messages.add(ChatMessage(
        id: replyId,
        role: MessageRole.assistant,
        content: '',
        isLoading: true,
        model: _settings.model,
      ));
    });
    _stick = true;
    _scrollToBottom();

    final history = _messages.where((m) => m.id != replyId).toList();
    final buf = StringBuffer();
    final clock = Stopwatch()..start();
    var lastUi = 0;

    try {
      await for (final chunk in _ai.streamReply(_settings, history)) {
        buf.write(chunk);
        if (clock.elapsedMilliseconds - lastUi > 60) {
          lastUi = clock.elapsedMilliseconds;
          _updateReply(replyId, buf.toString());
        }
      }
      if (buf.isEmpty) buf.write('(Model không trả về nội dung nào.)');
      _updateReply(replyId, buf.toString(), done: true);
    } catch (e) {
      if (_cancelled) {
        if (buf.isEmpty) {
          _removeMessage(replyId);
        } else {
          _updateReply(replyId, '${buf.toString()}\n\n*(đã dừng)*', done: true);
        }
      } else if (buf.isNotEmpty) {
        _updateReply(replyId, buf.toString(), done: true);
        _snack(AIService.friendlyError(e));
      } else {
        _updateReply(replyId, AIService.friendlyError(e), done: true, error: true);
      }
    }

    if (!mounted) return;
    setState(() {
      _busy = false;
      _status = '';
    });
    await ChatStore.save(_messages);
  }

  void _updateReply(String id, String content, {bool done = false, bool error = false}) {
    if (!mounted) return;
    final i = _messages.indexWhere((m) => m.id == id);
    if (i < 0) return;
    setState(() {
      _messages[i] = _messages[i].copyWith(
        content: content,
        isLoading: false,
        isError: error,
      );
    });
    if (_stick) _scrollToBottom(jump: !done);
  }

  void _removeMessage(String id) {
    if (!mounted) return;
    setState(() => _messages.removeWhere((m) => m.id == id));
  }

  void _stop() {
    _cancelled = true;
    _ai.cancel();
  }

  Future<void> _retry() async {
    if (_busy) return;
    while (_messages.isNotEmpty && _messages.last.role == MessageRole.assistant) {
      _messages.removeLast();
    }
    if (_messages.isEmpty) return;
    await _generate();
  }

  void _newChat() {
    if (_busy) return;
    setState(() {
      _messages.clear();
      _pending.clear();
    });
    ChatStore.clear();
  }

  // ------------------------------------------------------------------- misc

  void _scrollToBottom({bool jump = false}) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scroll.hasClients) return;
      final max = _scroll.position.maxScrollExtent;
      if (jump) {
        _scroll.jumpTo(max);
      } else {
        _scroll.animateTo(max, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  void _snack(String msg, {String? action, VoidCallback? onAction}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: KenzTheme.surfaceBg,
        behavior: SnackBarBehavior.floating,
        action: action == null ? null : SnackBarAction(label: action, onPressed: onAction ?? () {}),
      ),
    );
  }

  Future<void> _openSettings() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()));
    final s = await AppSettings.load();
    if (mounted) setState(() => _settings = s);
  }

  void _openModelSheet() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: KenzTheme.cardBg,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) {
          final p = _settings.preset;
          return SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Nhà cung cấp', style: TextStyle(color: KenzTheme.textSecondary)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (final pr in KenzProviders.all)
                        ChoiceChip(
                          label: Text(pr.name),
                          selected: pr.id == _settings.providerId,
                          onSelected: (_) async {
                            _settings.providerId = pr.id;
                            await _settings.save();
                            setSheet(() {});
                            if (mounted) setState(() {});
                          },
                        ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Text('Model (${p.name})', style: const TextStyle(color: KenzTheme.textSecondary)),
                  const SizedBox(height: 8),
                  if (p.models.isEmpty)
                    const Text('Nhập model trong Cài đặt.', style: TextStyle(color: KenzTheme.textPrimary))
                  else
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        for (final m in p.models)
                          ChoiceChip(
                            label: Text(m, style: const TextStyle(fontSize: 12)),
                            selected: m == _settings.model,
                            onSelected: (_) async {
                              _settings.models[p.id] = m;
                              await _settings.save();
                              setSheet(() {});
                              if (mounted) setState(() {});
                            },
                          ),
                      ],
                    ),
                  const SizedBox(height: 12),
                  TextButton.icon(
                    onPressed: () {
                      Navigator.pop(ctx);
                      _openSettings();
                    },
                    icon: const Icon(Icons.settings_outlined, size: 18),
                    label: const Text('API key & tuỳ chọn khác'),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // --------------------------------------------------------------------- UI

  Widget _pendingBar() {
    if (_pending.isEmpty) return const SizedBox.shrink();
    final hasDoc = _pending.any((a) => a.kind == AttachmentKind.document);
    return Container(
      color: KenzTheme.cardBg,
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 56,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: _pending.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) {
                final a = _pending[i];
                return Container(
                  padding: const EdgeInsets.only(left: 6, right: 2),
                  decoration: BoxDecoration(
                    color: KenzTheme.surfaceBg,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    children: [
                      if (a.kind == AttachmentKind.image)
                        ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: Image.file(File(a.path), width: 42, height: 42, fit: BoxFit.cover),
                        )
                      else
                        Icon(
                          a.kind == AttachmentKind.video ? Icons.videocam : Icons.description_outlined,
                          color: KenzTheme.neonBlue,
                          size: 28,
                        ),
                      const SizedBox(width: 8),
                      ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 130),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(a.name,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(color: KenzTheme.textPrimary, fontSize: 12)),
                            Text(a.sizeLabel,
                                style: const TextStyle(color: KenzTheme.textSecondary, fontSize: 11)),
                          ],
                        ),
                      ),
                      IconButton(
                        visualDensity: VisualDensity.compact,
                        icon: const Icon(Icons.close, size: 16, color: Colors.redAccent),
                        onPressed: () => setState(() => _pending.removeAt(i)),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          if (hasDoc)
            SizedBox(
              height: 40,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  for (final q in const [
                    'Tóm tắt nội dung chính',
                    'Tìm lỗi / vấn đề',
                    'Giải thích chi tiết',
                    'Đề xuất cải tiến',
                    'Viết test / báo cáo',
                  ])
                    Padding(
                      padding: const EdgeInsets.only(right: 6, top: 6),
                      child: ActionChip(
                        label: Text(q, style: const TextStyle(fontSize: 12)),
                        onPressed: _busy ? null : () => _send(override: q),
                      ),
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _modeRow() {
    return Container(
      color: KenzTheme.darkBg,
      padding: const EdgeInsets.fromLTRB(10, 6, 10, 0),
      child: Row(
        children: [
          Flexible(
            child: ActionChip(
              avatar: const Icon(Icons.memory, size: 16, color: KenzTheme.neonBlue),
              label: Text(
                '${_settings.preset.name} · ${_settings.model.isEmpty ? 'chưa chọn model' : _settings.model}',
                style: const TextStyle(fontSize: 12),
                overflow: TextOverflow.ellipsis,
              ),
              onPressed: _openModelSheet,
            ),
          ),
          const SizedBox(width: 8),
          FilterChip(
            avatar: const Icon(Icons.psychology_outlined, size: 16),
            label: const Text('Deep', style: TextStyle(fontSize: 12)),
            selected: _settings.deepMode,
            onSelected: (v) async {
              setState(() => _settings.deepMode = v);
              await _settings.save();
            },
          ),
          if (_status.isNotEmpty) ...[
            const SizedBox(width: 10),
            Expanded(
              child: Text(_status,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: KenzTheme.neonBlue, fontSize: 12)),
            ),
          ],
        ],
      ),
    );
  }

  Widget _empty() {
    const ideas = [
      'Viết hàm Python đọc CSV và vẽ biểu đồ',
      'Giải thích sự khác nhau giữa async và isolate trong Dart',
      'Review code giúp tôi (đính kèm tệp)',
    ];
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(40),
              child: Image.asset('assets/images/kenz_avatar.png', width: 80, height: 80, fit: BoxFit.cover),
            ),
            const SizedBox(height: 14),
            const Text('Xin chào, tôi là Kenz AI 🔥',
                style: TextStyle(color: KenzTheme.textPrimary, fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text(
              'Viết code, phân tích ảnh, và đọc tệp: code, log, CSV, JSON, PDF, Word, Excel, PowerPoint, ZIP '
              '(kể cả tệp rất lớn). Bấm dấu + để đính kèm.',
              textAlign: TextAlign.center,
              style: TextStyle(color: KenzTheme.textSecondary, height: 1.4),
            ),
            const SizedBox(height: 16),
            for (final i in ideas)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: ActionChip(label: Text(i, style: const TextStyle(fontSize: 12)), onPressed: () => _send(override: i)),
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Image.asset('assets/images/kenz_avatar.png', width: 36, height: 36, fit: BoxFit.cover),
            ),
            const SizedBox(width: 10),
            const Text('KENZ AI'),
          ],
        ),
        actions: [
          IconButton(icon: const Icon(Icons.add_comment_outlined), tooltip: 'Chat mới', onPressed: _newChat),
          IconButton(icon: const Icon(Icons.settings_outlined), tooltip: 'Cài đặt', onPressed: _openSettings),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: _messages.isEmpty
                ? _empty()
                : ListView.builder(
                    controller: _scroll,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    itemCount: _messages.length,
                    itemBuilder: (context, index) {
                      final m = _messages[index];
                      return MessageBubble(
                        key: ValueKey(m.id),
                        message: m,
                        onRetry: (m.isError && index == _messages.length - 1) ? _retry : null,
                      );
                    },
                  ),
          ),
          _pendingBar(),
          _modeRow(),
          InputBar(
            controller: _controller,
            busy: _busy,
            onSend: _send,
            onStop: _stop,
            onPickImages: _pickImages,
            onTakePhoto: _takePhoto,
            onPickVideo: _pickVideo,
            onPickFiles: _pickFiles,
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _scroll.dispose();
    super.dispose();
  }
}
