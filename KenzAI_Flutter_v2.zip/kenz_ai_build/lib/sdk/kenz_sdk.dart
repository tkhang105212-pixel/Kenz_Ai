/// Kenz SDK - lớp client AI đa nhà cung cấp (Claude, Grok, OpenAI, OpenRouter,
/// Groq, Gemini, tùy chỉnh) với streaming SSE, tự retry và hủy giữa chừng.
///
/// Dùng độc lập:
/// ```dart
/// final client = KenzClient(KenzOptions(
///   type: ProviderType.anthropic,
///   baseUrl: 'https://api.anthropic.com/v1',
///   apiKey: '...',
///   model: 'claude-sonnet-5-5',
/// ));
/// await for (final chunk in client.stream([ChatTurn('user', 'Xin chào')])) {
///   stdout.write(chunk);
/// }
/// ```
library kenz_sdk;

import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

enum ProviderType { openaiCompat, anthropic }

class ProviderPreset {
  final String id;
  final String name;
  final String baseUrl;
  final String defaultModel;
  final List<String> models;
  final ProviderType type;
  final String keyHint;

  /// Provider đọc được PDF trực tiếp (gồm cả hình/bảng trong PDF).
  final bool nativePdf;

  const ProviderPreset({
    required this.id,
    required this.name,
    required this.baseUrl,
    required this.defaultModel,
    required this.models,
    required this.type,
    required this.keyHint,
    this.nativePdf = false,
  });
}

class KenzProviders {
  static const claude = ProviderPreset(
    id: 'claude',
    name: 'Claude',
    baseUrl: 'https://api.anthropic.com/v1',
    defaultModel: 'claude-sonnet-5-5',
    models: ['claude-sonnet-5-5', 'claude-opus-5-5', 'claude-haiku-5-5'],
    type: ProviderType.anthropic,
    keyHint: 'sk-ant-...',
    nativePdf: true,
  );
  static const grok = ProviderPreset(
    id: 'grok',
    name: 'Grok (xAI)',
    baseUrl: 'https://api.x.ai/v1',
    defaultModel: 'grok-4',
    models: ['grok-4', 'grok-code-fast-1', 'grok-3', 'grok-3-mini', 'grok-2-vision-1212'],
    type: ProviderType.openaiCompat,
    keyHint: 'xai-...',
  );
  static const openai = ProviderPreset(
    id: 'openai',
    name: 'OpenAI',
    baseUrl: 'https://api.openai.com/v1',
    defaultModel: 'gpt-4o',
    models: ['gpt-4o', 'gpt-4o-mini', 'gpt-4.1'],
    type: ProviderType.openaiCompat,
    keyHint: 'sk-...',
  );
  static const openrouter = ProviderPreset(
    id: 'openrouter',
    name: 'OpenRouter',
    baseUrl: 'https://openrouter.ai/api/v1',
    defaultModel: 'anthropic/claude-sonnet-4.5',
    models: ['anthropic/claude-sonnet-4.5', 'openai/gpt-4o', 'x-ai/grok-4', 'google/gemini-2.5-pro'],
    type: ProviderType.openaiCompat,
    keyHint: 'sk-or-...',
  );
  static const groq = ProviderPreset(
    id: 'groq',
    name: 'Groq',
    baseUrl: 'https://api.groq.com/openai/v1',
    defaultModel: 'llama-3.3-70b-versatile',
    models: ['llama-3.3-70b-versatile', 'meta-llama/llama-4-scout-17b-16e-instruct'],
    type: ProviderType.openaiCompat,
    keyHint: 'gsk_...',
  );
  static const gemini = ProviderPreset(
    id: 'gemini',
    name: 'Gemini',
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai',
    defaultModel: 'gemini-2.5-flash',
    models: ['gemini-2.5-flash', 'gemini-2.5-pro'],
    type: ProviderType.openaiCompat,
    keyHint: 'AIza...',
  );
  static const custom = ProviderPreset(
    id: 'custom',
    name: 'Tùy chỉnh',
    baseUrl: 'http://localhost:11434/v1',
    defaultModel: '',
    models: [],
    type: ProviderType.openaiCompat,
    keyHint: 'key (có thể để trống với server local)',
  );

  static const all = [claude, grok, openai, openrouter, groq, gemini, custom];

  static ProviderPreset byId(String id) =>
      all.firstWhere((p) => p.id == id, orElse: () => grok);
}

class ImagePart {
  final String mime;
  final String data; // base64
  const ImagePart(this.mime, this.data);
}

class DocPart {
  final String name;
  final String mime;
  final String data; // base64
  const DocPart(this.name, this.mime, this.data);
}

class ChatTurn {
  final String role; // 'user' | 'assistant'
  final String text;
  final List<ImagePart> images;
  final List<DocPart> docs;
  const ChatTurn(this.role, this.text, {this.images = const [], this.docs = const []});
}

class KenzOptions {
  final ProviderType type;
  final String baseUrl;
  final String apiKey;
  final String model;
  final String system;
  final int maxTokens;
  final double temperature;
  final Duration connectTimeout;
  final Duration idleTimeout;
  final int maxRetries;

  const KenzOptions({
    required this.type,
    required this.baseUrl,
    required this.apiKey,
    required this.model,
    this.system = '',
    this.maxTokens = 8192,
    this.temperature = 0.7,
    this.connectTimeout = const Duration(seconds: 60),
    this.idleTimeout = const Duration(seconds: 120),
    this.maxRetries = 2,
  });
}

class KenzException implements Exception {
  final int? status;
  final String message;
  KenzException(this.message, {this.status});

  @override
  String toString() => status == null ? message : 'HTTP $status: $message';
}

class KenzClient {
  final KenzOptions options;
  http.Client? _active;

  KenzClient(this.options);

  /// Hủy request đang chạy (stream sẽ ném lỗi, caller tự bỏ qua).
  void cancel() {
    _active?.close();
    _active = null;
  }

  Future<String> complete(List<ChatTurn> turns) async {
    final sb = StringBuffer();
    await for (final c in stream(turns)) {
      sb.write(c);
    }
    return sb.toString();
  }

  Stream<String> stream(List<ChatTurn> turns) async* {
    final client = http.Client();
    _active = client;
    try {
      late http.StreamedResponse res;
      for (var attempt = 0;; attempt++) {
        final req = _buildRequest(turns);
        res = await client.send(req).timeout(options.connectTimeout);
        if (res.statusCode == 200) break;
        final body = await res.stream.bytesToString();
        final retriable = res.statusCode == 429 || res.statusCode >= 500;
        if (retriable && attempt < options.maxRetries) {
          await Future<void>.delayed(Duration(seconds: 2 * (attempt + 1)));
          continue;
        }
        throw KenzException(_errorMessage(body), status: res.statusCode);
      }
      final claude = options.type == ProviderType.anthropic;
      await for (final data in _sse(res.stream.timeout(options.idleTimeout))) {
        final piece = claude ? _parseClaude(data) : _parseOpenAI(data);
        if (piece != null && piece.isNotEmpty) yield piece;
      }
    } finally {
      client.close();
      if (identical(_active, client)) _active = null;
    }
  }

  // ---------------------------------------------------------------- request

  String _base() => options.baseUrl.replaceAll(RegExp(r'/+$'), '');

  http.Request _buildRequest(List<ChatTurn> turns) {
    final turnsN = _normalize(turns);
    if (options.type == ProviderType.anthropic) {
      final req = http.Request('POST', Uri.parse('${_base()}/messages'));
      req.headers.addAll({
        'content-type': 'application/json',
        'x-api-key': options.apiKey,
        'anthropic-version': '2023-06-01',
      });
      req.body = jsonEncode(_claudeBody(turnsN));
      return req;
    }
    final req = http.Request('POST', Uri.parse('${_base()}/chat/completions'));
    req.headers['content-type'] = 'application/json';
    if (options.apiKey.isNotEmpty) {
      req.headers['authorization'] = 'Bearer ${options.apiKey}';
    }
    req.body = jsonEncode(_openAIBody(turnsN));
    return req;
  }

  /// Bỏ turn assistant ở đầu + gộp các turn liên tiếp cùng role
  /// (Claude yêu cầu bắt đầu bằng user và xen kẽ role).
  List<ChatTurn> _normalize(List<ChatTurn> turns) {
    final out = <ChatTurn>[];
    for (final t in turns) {
      if (out.isEmpty && t.role != 'user') continue;
      if (out.isNotEmpty && out.last.role == t.role) {
        final p = out.removeLast();
        out.add(ChatTurn(
          t.role,
          '${p.text}\n\n${t.text}',
          images: [...p.images, ...t.images],
          docs: [...p.docs, ...t.docs],
        ));
      } else {
        out.add(t);
      }
    }
    return out;
  }

  Map<String, dynamic> _claudeBody(List<ChatTurn> turns) {
    final msgs = <Map<String, dynamic>>[];
    for (final t in turns) {
      final text = t.text.trim().isEmpty ? '(trống)' : t.text;
      if (t.role == 'assistant') {
        msgs.add({'role': 'assistant', 'content': text});
        continue;
      }
      final blocks = <Map<String, dynamic>>[];
      for (final d in t.docs) {
        blocks.add({
          'type': 'document',
          'title': d.name,
          'source': {'type': 'base64', 'media_type': d.mime, 'data': d.data},
        });
      }
      for (final i in t.images) {
        blocks.add({
          'type': 'image',
          'source': {'type': 'base64', 'media_type': i.mime, 'data': i.data},
        });
      }
      blocks.add({'type': 'text', 'text': text});
      msgs.add({'role': 'user', 'content': blocks});
    }
    final body = <String, dynamic>{
      'model': options.model,
      'max_tokens': options.maxTokens,
      'stream': true,
      'messages': msgs,
    };
    if (options.system.isNotEmpty) body['system'] = options.system;
    // Claude: dùng temperature mặc định của model (một số model mới không cho chỉnh).
    return body;
  }

  Map<String, dynamic> _openAIBody(List<ChatTurn> turns) {
    final msgs = <Map<String, dynamic>>[];
    if (options.system.isNotEmpty) {
      msgs.add({'role': 'system', 'content': options.system});
    }
    for (final t in turns) {
      if (t.images.isEmpty || t.role != 'user') {
        msgs.add({'role': t.role, 'content': t.text});
      } else {
        msgs.add({
          'role': 'user',
          'content': [
            {'type': 'text', 'text': t.text},
            for (final i in t.images)
              {
                'type': 'image_url',
                'image_url': {'url': 'data:${i.mime};base64,${i.data}'},
              },
          ],
        });
      }
    }
    final isOpenAI = options.baseUrl.contains('api.openai.com');
    final reasoning = isOpenAI &&
        (options.model.startsWith('o') || options.model.startsWith('gpt-5'));
    final body = <String, dynamic>{
      'model': options.model,
      'messages': msgs,
      'stream': true,
    };
    body[isOpenAI ? 'max_completion_tokens' : 'max_tokens'] = options.maxTokens;
    if (!reasoning) body['temperature'] = options.temperature;
    return body;
  }

  // --------------------------------------------------------------- response

  Stream<String> _sse(Stream<List<int>> bytes) async* {
    final lines = bytes
        .transform(const Utf8Decoder(allowMalformed: true))
        .transform(const LineSplitter());
    await for (final line in lines) {
      if (!line.startsWith('data:')) continue;
      final d = line.substring(5).trim();
      if (d.isEmpty || d == '[DONE]') continue;
      yield d;
    }
  }

  dynamic _tryJson(String s) {
    try {
      return jsonDecode(s);
    } catch (_) {
      return null;
    }
  }

  String? _parseOpenAI(String data) {
    final j = _tryJson(data);
    if (j is! Map) return null;
    if (j['error'] != null) throw KenzException(_errorMessage(data));
    final choices = j['choices'];
    if (choices is List && choices.isNotEmpty && choices[0] is Map) {
      final delta = (choices[0] as Map)['delta'];
      if (delta is Map && delta['content'] is String) {
        return delta['content'] as String;
      }
    }
    return null;
  }

  String? _parseClaude(String data) {
    final j = _tryJson(data);
    if (j is! Map) return null;
    final type = j['type'];
    if (type == 'error') throw KenzException(_errorMessage(data));
    if (type == 'content_block_delta') {
      final d = j['delta'];
      if (d is Map && d['type'] == 'text_delta' && d['text'] is String) {
        return d['text'] as String;
      }
    }
    return null;
  }

  String _errorMessage(String body) {
    final j = _tryJson(body);
    if (j is Map) {
      final e = j['error'];
      if (e is Map && e['message'] != null) return '${e['message']}';
      if (e is String) return e;
      if (j['message'] != null) return '${j['message']}';
    }
    if (j is List && j.isNotEmpty && j[0] is Map) {
      final e = (j[0] as Map)['error'];
      if (e is Map && e['message'] != null) return '${e['message']}';
    }
    final t = body.trim();
    return t.length > 600 ? '${t.substring(0, 600)}…' : t;
  }
}
