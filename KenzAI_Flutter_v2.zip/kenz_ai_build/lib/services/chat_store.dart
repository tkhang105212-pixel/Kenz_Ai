import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../models/message.dart';

/// Lưu hội thoại ra file JSON trong thư mục app (không giới hạn như SharedPreferences).
class ChatStore {
  static Future<File> _file() async {
    final d = await getApplicationDocumentsDirectory();
    return File('${d.path}/kenz_chat.json');
  }

  static Future<List<ChatMessage>> load() async {
    try {
      final f = await _file();
      if (!await f.exists()) return [];
      final list = jsonDecode(await f.readAsString()) as List;
      return list
          .map((e) => ChatMessage.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> save(List<ChatMessage> messages) async {
    try {
      final keep = messages.where((m) => !m.isLoading).toList();
      final tail = keep.length > 200 ? keep.sublist(keep.length - 200) : keep;
      final f = await _file();
      await f.writeAsString(jsonEncode(tail.map((m) => m.toJson()).toList()));
    } catch (_) {}
  }

  static Future<void> clear() async {
    try {
      final f = await _file();
      if (await f.exists()) await f.delete();
    } catch (_) {}
  }
}
