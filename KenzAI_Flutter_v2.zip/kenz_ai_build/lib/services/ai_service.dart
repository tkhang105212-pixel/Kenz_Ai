import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:http/http.dart' as http;
import '../models/attachment.dart';
import '../models/message.dart';
import '../sdk/kenz_sdk.dart';
import 'file_analyzer.dart';
import 'settings_store.dart';

class AIService {
  KenzClient? _client;

  void cancel() {
    _client?.cancel();
    _client = null;
  }

  String buildSystemPrompt(AppSettings s) {
    final sb = StringBuffer('''Bạn là Kenz AI - trợ lý chuyên viết code và phân tích tệp/ảnh/tài liệu.
- Model nền hiện tại do người dùng cấu hình: ${s.model} (${s.preset.name}). Nếu được hỏi, nói thật điều này.
- Viết code sạch, đúng best practice, comment tiếng Việt khi cần. Hỗ trợ mọi ngôn ngữ lập trình.
- Các khối "=== FILE: tên ... === ... === END FILE ===" là nội dung tệp người dùng đính kèm đã được trích xuất sẵn trên máy. Hãy dựa vào đó, nêu rõ tên tệp/số dòng khi trích dẫn.
- Nếu nội dung bị lược ("đã lược ...") hoặc không trích được, hãy nói rõ giới hạn đó thay vì đoán.
- Với ảnh: mô tả chi tiết, đọc chữ trong ảnh, phân tích UI/UX, tìm lỗi trong ảnh chụp code.
- Với dữ liệu (CSV/Excel/JSON): dùng thống kê đã cung cấp, nêu bất thường, gợi ý cách phân tích tiếp.
- Trả lời bằng ngôn ngữ người dùng đang dùng, ngắn gọn đúng trọng tâm, dùng markdown và code block có ghi ngôn ngữ.''');
    if (s.deepMode) {
      sb.write('''

[CHẾ ĐỘ DEEP] Hãy suy luận kỹ từng bước trước khi kết luận: nêu giả định, cân nhắc phương án thay thế, tự rà soát lỗi/edge case của câu trả lời và code trước khi trả lời. Với tệp lớn, đối chiếu chéo các phần.''');
    }
    if (s.customPrompt.trim().isNotEmpty) {
      sb.write('\n\nChỉ dẫn thêm từ người dùng:\n${s.customPrompt.trim()}');
    }
    return sb.toString();
  }

  KenzOptions _options(AppSettings s, {int? maxTokens, String? system}) {
    return KenzOptions(
      type: s.preset.type,
      baseUrl: s.baseUrl,
      apiKey: s.apiKey,
      model: s.model,
      system: system ?? buildSystemPrompt(s),
      maxTokens: maxTokens ?? s.maxTokens,
      temperature: s.temperature,
    );
  }

  /// Gửi lịch sử, nhận câu trả lời dạng stream.
  Stream<String> streamReply(AppSettings s, List<ChatMessage> history) async* {
    final turns = await buildTurns(history, s);
    final client = KenzClient(_options(s));
    _client = client;
    try {
      yield* client.stream(turns);
    } finally {
      if (identical(_client, client)) _client = null;
    }
  }

  /// Kiểm tra key/model/base URL bằng 1 request nhỏ.
  Future<String> test(AppSettings s) async {
    final client = KenzClient(_options(s, maxTokens: 32, system: 'Trả lời đúng 1 từ: OK'));
    try {
      final r = await client.complete([const ChatTurn('user', 'ping')]);
      return '✅ Kết nối được. Model trả lời: ${r.trim().isEmpty ? '(rỗng)' : r.trim()}';
    } catch (e) {
      return friendlyError(e);
    }
  }

  Future<List<ChatTurn>> buildTurns(List<ChatMessage> all, AppSettings s) async {
    final msgs = all
        .where((m) =>
            !m.isLoading &&
            !m.isError &&
            (m.content.trim().isNotEmpty ||
                m.attachments.isNotEmpty ||
                (m.fileContext?.isNotEmpty ?? false)))
        .toList();
    final start = msgs.length > s.historyTurns ? msgs.length - s.historyTurns : 0;
    final window = msgs.sublist(start);
    // Ảnh/PDF gốc chỉ gửi lại cho 6 tin gần nhất để tiết kiệm token.
    final mediaFrom = window.length > 6 ? window.length - 6 : 0;
    final pdfBudget = (s.charBudget / 2).floor();

    final turns = <ChatTurn>[];
    for (var i = 0; i < window.length; i++) {
      final m = window[i];
      if (m.role == MessageRole.assistant) {
        turns.add(ChatTurn('assistant', m.content));
        continue;
      }
      final ctx = StringBuffer(m.fileContext ?? '');
      final images = <ImagePart>[];
      final docs = <DocPart>[];
      for (final a in m.attachments) {
        if (a.kind == AttachmentKind.image) {
          if (i < mediaFrom) {
            ctx.writeln('\n[Ảnh ${a.name} đã được lược khỏi ngữ cảnh cũ]');
            continue;
          }
          final p = await _imagePart(a.path);
          if (p != null) {
            images.add(p);
          } else {
            ctx.writeln('\n[Không đọc được ảnh ${a.name}]');
          }
        } else if (a.kind == AttachmentKind.document && a.nativePdf) {
          if (i < mediaFrom) {
            ctx.writeln('\n[PDF ${a.name} đã được lược khỏi ngữ cảnh cũ]');
          } else if (s.preset.nativePdf) {
            try {
              final bytes = await File(a.path).readAsBytes();
              docs.add(DocPart(a.name, 'application/pdf', base64Encode(bytes)));
            } catch (_) {
              ctx.writeln('\n[Không đọc được PDF ${a.name}]');
            }
          } else {
            // Đã đổi sang provider không đọc PDF trực tiếp -> trích văn bản.
            ctx.writeln('\n${await FileAnalyzer.pdfContext(a, pdfBudget)}');
          }
        }
      }
      final c = ctx.toString().trim();
      final body = c.isEmpty ? m.content : '$c\n\nYêu cầu của người dùng:\n${m.content}';
      turns.add(ChatTurn('user', body, images: images, docs: docs));
    }
    return turns;
  }

  Future<ImagePart?> _imagePart(String path) async {
    try {
      var bytes = await File(path).readAsBytes();
      var mime = _mime(path);
      if (bytes.length > 3500000) {
        // Thu nhỏ ảnh lớn để không vượt giới hạn của API.
        final codec = await ui.instantiateImageCodec(bytes, targetWidth: 1600);
        final frame = await codec.getNextFrame();
        final data = await frame.image.toByteData(format: ui.ImageByteFormat.png);
        if (data != null) {
          bytes = data.buffer.asUint8List();
          mime = 'image/png';
        }
      }
      return ImagePart(mime, base64Encode(bytes));
    } catch (_) {
      return null;
    }
  }

  String _mime(String path) {
    switch (path.toLowerCase().split('.').last) {
      case 'png':
        return 'image/png';
      case 'gif':
        return 'image/gif';
      case 'webp':
        return 'image/webp';
      default:
        return 'image/jpeg';
    }
  }

  static String friendlyError(Object e) {
    if (e is KenzException) {
      final st = e.status;
      var hint = '';
      if (st == 401 || st == 403) {
        hint = '\n\n👉 API Key sai hoặc không có quyền dùng model này. Kiểm tra trong Cài đặt.';
      } else if (st == 404) {
        hint = '\n\n👉 Model hoặc Base URL không đúng.';
      } else if (st == 413 || e.message.toLowerCase().contains('too long') || e.message.toLowerCase().contains('context')) {
        hint = '\n\n👉 Nội dung vượt giới hạn ngữ cảnh. Giảm "Ngân sách nội dung tệp" trong Cài đặt hoặc gửi ít tệp hơn.';
      } else if (st == 429) {
        hint = '\n\n👉 Hết quota hoặc bị giới hạn tốc độ. Đợi một lát rồi thử lại.';
      } else if (st == 400 && e.message.toLowerCase().contains('max_tokens')) {
        hint = '\n\n👉 "Độ dài trả lời tối đa" vượt mức model cho phép. Giảm trong Cài đặt.';
      }
      return '❌ Lỗi API: ${e.message}$hint';
    }
    if (e is TimeoutException) {
      return '⏱️ Hết thời gian chờ phản hồi. Thử lại hoặc chọn model nhanh hơn.';
    }
    if (e is SocketException || e is http.ClientException) {
      return '❌ Lỗi kết nối: kiểm tra mạng / Base URL.\n${e.toString()}';
    }
    return '❌ Lỗi: $e';
  }
}
