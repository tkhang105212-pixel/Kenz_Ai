import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../sdk/kenz_sdk.dart';

class AppSettings {
  String providerId;
  Map<String, String> keys;
  Map<String, String> models;
  Map<String, String> baseUrls;
  int maxTokens;
  double temperature;
  bool deepMode;
  String customPrompt;
  int historyTurns;

  /// Tổng số ký tự nội dung tệp được đưa vào 1 tin nhắn (~4 ký tự ≈ 1 token).
  int charBudget;

  AppSettings({
    this.providerId = 'grok',
    Map<String, String>? keys,
    Map<String, String>? models,
    Map<String, String>? baseUrls,
    this.maxTokens = 8192,
    this.temperature = 0.7,
    this.deepMode = false,
    this.customPrompt = '',
    this.historyTurns = 40,
    this.charBudget = 600000,
  })  : keys = keys ?? {},
        models = models ?? {},
        baseUrls = baseUrls ?? {};

  ProviderPreset get preset => KenzProviders.byId(providerId);

  String get apiKey => keys[providerId] ?? '';

  String get model {
    final m = models[providerId];
    return (m != null && m.isNotEmpty) ? m : preset.defaultModel;
  }

  String get baseUrl {
    final b = baseUrls[providerId];
    return (b != null && b.isNotEmpty) ? b : preset.baseUrl;
  }

  static const _prefKey = 'kenz_settings_v2';

  static Future<AppSettings> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_prefKey);
    final s = AppSettings();
    if (raw != null) {
      try {
        final j = jsonDecode(raw) as Map<String, dynamic>;
        s.providerId = (j['providerId'] as String?) ?? s.providerId;
        s.keys = Map<String, String>.from((j['keys'] as Map?) ?? {});
        s.models = Map<String, String>.from((j['models'] as Map?) ?? {});
        s.baseUrls = Map<String, String>.from((j['baseUrls'] as Map?) ?? {});
        s.maxTokens = (j['maxTokens'] as num?)?.toInt() ?? s.maxTokens;
        s.temperature = (j['temperature'] as num?)?.toDouble() ?? s.temperature;
        s.deepMode = j['deepMode'] == true;
        s.customPrompt = (j['customPrompt'] as String?) ?? '';
        s.historyTurns = (j['historyTurns'] as num?)?.toInt() ?? s.historyTurns;
        s.charBudget = (j['charBudget'] as num?)?.toInt() ?? s.charBudget;
      } catch (_) {}
      return s;
    }
    // Di chuyển cấu hình cũ (bản 1.0)
    final k = prefs.getString('api_key');
    if (k != null && k.isNotEmpty) {
      final b = prefs.getString('base_url') ?? '';
      final m = prefs.getString('model');
      String id;
      if (b.isEmpty || b.contains('x.ai')) {
        id = 'grok';
      } else if (b.contains('openai.com')) {
        id = 'openai';
      } else if (b.contains('openrouter')) {
        id = 'openrouter';
      } else if (b.contains('groq')) {
        id = 'groq';
      } else if (b.contains('anthropic')) {
        id = 'claude';
      } else {
        id = 'custom';
        s.baseUrls[id] = b;
      }
      s.providerId = id;
      s.keys[id] = k;
      if (m != null && m.isNotEmpty) s.models[id] = m;
    }
    return s;
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _prefKey,
      jsonEncode({
        'providerId': providerId,
        'keys': keys,
        'models': models,
        'baseUrls': baseUrls,
        'maxTokens': maxTokens,
        'temperature': temperature,
        'deepMode': deepMode,
        'customPrompt': customPrompt,
        'historyTurns': historyTurns,
        'charBudget': charBudget,
      }),
    );
  }
}
