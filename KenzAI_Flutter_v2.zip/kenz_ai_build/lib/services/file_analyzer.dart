import 'dart:collection';
import 'dart:convert';
import 'dart:io';
import 'dart:isolate';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:archive/archive.dart';
import '../models/attachment.dart';

class AnalysisResult {
  final String context;
  final Set<String> nativePdfPaths;
  const AnalysisResult(this.context, this.nativePdfPaths);
}

/// Phân tích tệp cục bộ trước khi gửi cho model:
/// - Văn bản/code/log: đọc dạng stream (hỗ trợ file nhiều GB), lấy đầu + cuối,
///   đếm dòng, gom dòng lỗi, dựng outline code.
/// - CSV/TSV: schema + thống kê từng cột trên toàn bộ file.
/// - JSON: cấu trúc (key/kiểu/độ dài mảng).
/// - ZIP: cây thư mục + nội dung các tệp quan trọng nhất.
/// - DOCX/XLSX/PPTX: trích văn bản/bảng.
/// - PDF: gửi thẳng cho Claude, hoặc trích văn bản cơ bản.
/// - Nhị phân lạ: hex header + chuỗi đọc được.
/// Toàn bộ chạy trong isolate nền nên UI không bị đứng.
class FileAnalyzer {
  static const _textExts = {
    'txt', 'md', 'markdown', 'log', 'rst', 'tex', 'srt', 'vtt', 'env', 'gitignore',
    'json', 'jsonl', 'ndjson', 'geojson', 'svg', 'csv', 'tsv',
    'dart', 'kt', 'kts', 'java', 'py', 'js', 'jsx', 'ts', 'tsx', 'c', 'h', 'cpp', 'hpp',
    'cc', 'cs', 'go', 'rs', 'swift', 'rb', 'php', 'sh', 'bash', 'sql', 'lua', 'scala',
    'r', 'm', 'gradle', 'vue', 'svelte', 'html', 'htm', 'css', 'scss', 'xml', 'yaml',
    'yml', 'toml', 'ini', 'cfg', 'properties', 'bat', 'ps1', 'tf', 'proto', 'graphql',
    'dockerfile', 'makefile', 'cmake', 'conf',
  };

  static const _codeExts = {
    'dart', 'kt', 'kts', 'java', 'py', 'js', 'jsx', 'ts', 'tsx', 'c', 'h', 'cpp', 'hpp',
    'cc', 'cs', 'go', 'rs', 'swift', 'rb', 'php', 'sh', 'bash', 'lua', 'scala', 'vue',
    'svelte',
  };

  static const _bigTextBytes = 8 * 1024 * 1024; // trên mức này: quét stream
  static const _maxInMemory = 300 * 1024 * 1024; // zip/docx/xlsx/pptx/pdf-text
  static const _nativePdfMax = 30 * 1024 * 1024;
  static const _maxPdfText = 100 * 1024 * 1024;

  static final _outlineRe = RegExp(
    r'^\s*(?:@\w+\s+)?(?:(?:export|public|private|protected|static|abstract|async|final|override|suspend|data|open|sealed|default)\s+)*'
    r'(?:class|interface|enum|struct|trait|def|fun|func|function|fn|mixin|extension|object|impl)\s+[A-Za-z_]\w*',
  );

  // ------------------------------------------------------------ public API

  static Future<AnalysisResult> analyze(
    List<Attachment> files, {
    required bool providerNativePdf,
    required int totalCharBudget,
  }) async {
    final items = files.where((f) => f.kind != AttachmentKind.image).toList();
    final sb = StringBuffer();
    final native = <String>{};
    if (items.isEmpty) return AnalysisResult('', native);

    final per = math.max(20000, (totalCharBudget / items.length).floor());
    for (final f in items) {
      if (f.kind == AttachmentKind.video) {
        sb.writeln('=== FILE: ${f.name} (video, ${f.sizeLabel}) ===');
        sb.writeln('[Video chưa thể đưa trực tiếp cho model. Nếu cần phân tích, hãy gửi vài ảnh chụp màn hình/khung hình quan trọng.]');
        sb.writeln('=== END FILE ===\n');
        continue;
      }
      try {
        final r = await Isolate.run(() => _analyzeOne(f, per, providerNativePdf));
        sb.writeln(r.$1);
        if (r.$2) native.add(f.path);
      } catch (e) {
        sb.writeln('=== FILE: ${f.name} (${f.sizeLabel}) ===\n[Không đọc được tệp: $e]\n=== END FILE ===\n');
      }
    }
    return AnalysisResult(sb.toString().trim(), native);
  }

  /// Dùng khi model hiện tại không đọc PDF trực tiếp.
  static Future<String> pdfContext(Attachment a, int budget) async {
    try {
      return await Isolate.run(() async {
        final size = await File(a.path).length();
        final body = size > _maxPdfText
            ? '[PDF quá lớn để trích văn bản]'
            : _pdfText(await File(a.path).readAsBytes(), budget);
        return '=== FILE: ${a.name} (PDF, ${a.sizeLabel}) ===\n$body\n=== END FILE ===';
      });
    } catch (e) {
      return '=== FILE: ${a.name} ===\n[Không đọc được PDF: $e]\n=== END FILE ===';
    }
  }

  // ---------------------------------------------------------- per-file work

  static Future<(String, bool)> _analyzeOne(Attachment f, int budget, bool nativePdf) async {
    final file = File(f.path);
    final size = await file.length();
    final ext = f.ext;
    final head = '=== FILE: ${f.name} (${Attachment.formatBytes(size)}) ===';
    String body;
    var native = false;

    switch (ext) {
      case 'pdf':
        if (nativePdf && size <= _nativePdfMax) {
          native = true;
          body = '[PDF được gửi trực tiếp cho model đọc, gồm cả hình ảnh và bảng.]';
        } else if (size > _maxPdfText) {
          body = '[PDF quá lớn (${Attachment.formatBytes(size)}) để xử lý.]';
        } else {
          body = _pdfText(await file.readAsBytes(), budget);
        }
        break;
      case 'docx':
      case 'xlsx':
      case 'pptx':
      case 'zip':
        if (size > _maxInMemory) {
          body = '[Tệp quá lớn (${Attachment.formatBytes(size)}) để giải nén trong bộ nhớ. Hãy tách nhỏ.]';
        } else {
          final bytes = await file.readAsBytes();
          if (ext == 'docx') {
            body = _clip(_docx(bytes), budget);
          } else if (ext == 'xlsx') {
            body = _clip(_xlsx(bytes), budget);
          } else if (ext == 'pptx') {
            body = _clip(_pptx(bytes), budget);
          } else {
            body = _zip(bytes, budget);
          }
        }
        break;
      case 'csv':
      case 'tsv':
        body = await _csv(file, size, ext, budget);
        break;
      case 'json':
        body = await _json(file, size, budget);
        break;
      default:
        if (_textExts.contains(ext) || await _looksLikeText(file)) {
          body = await _text(file, size, ext, budget);
        } else {
          body = await _binary(file, size);
        }
    }
    return ('$head\n$body\n=== END FILE ===\n', native);
  }

  // ------------------------------------------------------------------- text

  static Future<bool> _looksLikeText(File f) async {
    final b = await _readBytes(f, 0, 8192);
    if (b.isEmpty) return true;
    if (b.contains(0)) return false;
    final ok = b.where((x) => x == 9 || x == 10 || x == 13 || (x >= 32 && x < 127) || x >= 128).length;
    return ok / b.length > 0.92;
  }

  static Future<Uint8List> _readBytes(File f, int start, int end) async {
    final raf = await f.open();
    try {
      final len = await raf.length();
      final s = math.min(math.max(start, 0), len);
      final e = math.min(math.max(end, s), len);
      await raf.setPosition(s);
      return await raf.read(e - s);
    } finally {
      await raf.close();
    }
  }

  static Future<String> _text(File file, int size, String ext, int budget) async {
    final isCode = _codeExts.contains(ext);
    if (size > _bigTextBytes) return _scanBigText(file, size, budget);

    final content = utf8.decode(await file.readAsBytes(), allowMalformed: true);
    final lines = content.split('\n');
    final sb = StringBuffer('Số dòng: ${lines.length}\n');

    if (isCode && lines.length > 200) {
      final outline = <String>[];
      for (var i = 0; i < lines.length && outline.length < 120; i++) {
        if (_outlineRe.hasMatch(lines[i])) outline.add('${i + 1}: ${lines[i].trim()}');
      }
      if (outline.isNotEmpty) {
        sb.writeln('Outline (dòng: khai báo):');
        sb.writeln(outline.join('\n'));
        sb.writeln('--- nội dung ---');
      }
    }
    final errRe = _errRe;
    var errs = 0;
    if (ext == 'log' || ext == 'txt') {
      for (final l in lines) {
        if (errRe.hasMatch(l)) errs++;
      }
      if (errs > 0) sb.writeln('Số dòng có lỗi/exception: $errs');
    }
    sb.write(_clip(content, budget));
    return sb.toString();
  }

  static final _errRe = RegExp(
    r'\b(error|exception|fatal|fail(?:ed|ure)?|panic|traceback|critical)\b',
    caseSensitive: false,
  );
  static final _warnRe = RegExp(r'\bwarn(?:ing)?\b', caseSensitive: false);

  /// Quét tệp rất lớn (có thể vài GB) bằng stream: không nạp cả file vào RAM.
  static Future<String> _scanBigText(File file, int size, int budget) async {
    final headLimit = (budget * 0.55).toInt();
    final tailLimit = (budget * 0.25).toInt();
    final head = StringBuffer();
    var headChars = 0;
    final tail = Queue<String>();
    var tailChars = 0;
    final errFirst = <String>[];
    final errLast = Queue<String>();
    var lines = 0, errors = 0, warns = 0;

    final stream = file
        .openRead()
        .transform(const Utf8Decoder(allowMalformed: true))
        .transform(const LineSplitter());
    await for (final raw in stream) {
      lines++;
      final l = raw.length > 2000 ? raw.substring(0, 2000) : raw;
      if (headChars < headLimit) {
        head.writeln(l);
        headChars += l.length + 1;
      } else {
        tail.addLast(l);
        tailChars += l.length + 1;
        while (tailChars > tailLimit && tail.isNotEmpty) {
          tailChars -= tail.removeFirst().length + 1;
        }
      }
      if (_errRe.hasMatch(l)) {
        errors++;
        final e = '$lines: ${l.length > 300 ? l.substring(0, 300) : l}';
        if (errFirst.length < 15) {
          errFirst.add(e);
        } else {
          errLast.addLast(e);
          if (errLast.length > 15) errLast.removeFirst();
        }
      } else if (_warnRe.hasMatch(l)) {
        warns++;
      }
    }

    final sb = StringBuffer();
    sb.writeln('[Tệp lớn: đã quét toàn bộ bằng stream, chỉ gửi phần đầu/cuối và dòng lỗi]');
    sb.writeln('Tổng số dòng: $lines | dòng lỗi/exception: $errors | cảnh báo: $warns');
    if (errFirst.isNotEmpty) {
      sb.writeln('\nDòng lỗi đầu tiên:\n${errFirst.join('\n')}');
    }
    if (errLast.isNotEmpty) {
      sb.writeln('\nDòng lỗi gần cuối:\n${errLast.join('\n')}');
    }
    sb.writeln('\n--- PHẦN ĐẦU ---\n$head');
    sb.writeln('[... lược phần giữa ...]');
    sb.writeln('--- PHẦN CUỐI ---\n${tail.join('\n')}');
    return sb.toString();
  }

  // -------------------------------------------------------------------- csv

  static Future<String> _csv(File file, int size, String ext, int budget) async {
    var delim = ext == 'tsv' ? '\t' : ',';
    var gotHeader = false;
    var header = <String>[];
    var cols = <_Col>[];
    final samples = <List<String>>[];
    var rows = 0;

    final stream = file
        .openRead()
        .transform(const Utf8Decoder(allowMalformed: true))
        .transform(const LineSplitter());
    await for (final line in stream) {
      if (line.trim().isEmpty) continue;
      if (!gotHeader) {
        if (ext != 'tsv') {
          final counts = {
            ',': ','.allMatches(line).length,
            ';': ';'.allMatches(line).length,
            '\t': '\t'.allMatches(line).length,
            '|': '|'.allMatches(line).length,
          };
          delim = counts.entries.reduce((a, b) => b.value > a.value ? b : a).key;
        }
        header = _splitCsv(line, delim);
        cols = List.generate(header.length, (_) => _Col());
        gotHeader = true;
        continue;
      }
      rows++;
      final cells = _splitCsv(line, delim);
      if (samples.length < 8) samples.add(cells);
      for (var i = 0; i < cells.length && i < cols.length; i++) {
        cols[i].add(cells[i]);
      }
    }

    final sb = StringBuffer();
    sb.writeln('Số dòng dữ liệu: $rows | số cột: ${header.length} | phân cách: ${delim == '\t' ? 'TAB' : delim}');
    sb.writeln('\nThống kê từng cột (tính trên toàn bộ file):');
    for (var i = 0; i < header.length; i++) {
      sb.writeln('- ${header[i]}: ${cols[i].describe(rows)}');
    }
    if (size <= budget) {
      sb.writeln('\n--- toàn bộ nội dung ---');
      sb.write(utf8.decode(await file.readAsBytes(), allowMalformed: true));
    } else {
      sb.writeln('\n--- 8 dòng đầu ---');
      sb.writeln(header.join(' | '));
      for (final r in samples) {
        sb.writeln(r.join(' | '));
      }
    }
    return sb.toString();
  }

  static List<String> _splitCsv(String line, String d) {
    final out = <String>[];
    final cur = StringBuffer();
    var q = false;
    for (var i = 0; i < line.length; i++) {
      final c = line[i];
      if (c == '"') {
        if (q && i + 1 < line.length && line[i + 1] == '"') {
          cur.write('"');
          i++;
        } else {
          q = !q;
        }
      } else if (c == d && !q) {
        out.add(cur.toString());
        cur.clear();
      } else {
        cur.write(c);
      }
    }
    out.add(cur.toString());
    return out;
  }

  // ------------------------------------------------------------------- json

  static Future<String> _json(File file, int size, int budget) async {
    final sb = StringBuffer();
    if (size <= 40 * 1024 * 1024) {
      final text = utf8.decode(await file.readAsBytes(), allowMalformed: true);
      try {
        final data = jsonDecode(text);
        final shape = StringBuffer();
        _shape(data, r'$', shape, 0);
        sb.writeln('Cấu trúc JSON:\n$shape');
      } catch (e) {
        sb.writeln('[Không parse được JSON hợp lệ: ${e.toString().split('\n').first}]');
      }
      sb.writeln('--- nội dung ---');
      sb.write(_clip(text, budget));
    } else {
      sb.writeln('[JSON lớn: chỉ gửi phần đầu và cuối]');
      sb.writeln(_clip(await _readHeadTail(file, size, budget), budget));
    }
    return sb.toString();
  }

  static Future<String> _readHeadTail(File f, int size, int budget) async {
    final h = await _readBytes(f, 0, (budget * 0.65).toInt());
    final t = await _readBytes(f, size - (budget * 0.25).toInt(), size);
    return '${utf8.decode(h, allowMalformed: true)}\n[... lược phần giữa ...]\n${utf8.decode(t, allowMalformed: true)}';
  }

  static void _shape(dynamic v, String path, StringBuffer sb, int depth) {
    if (depth > 4 || sb.length > 6000) return;
    if (v is Map) {
      sb.writeln('$path: object (${v.length} key)');
      var n = 0;
      for (final e in v.entries) {
        if (n++ >= 25) {
          sb.writeln('$path: ... còn ${v.length - 25} key nữa');
          break;
        }
        _shape(e.value, '$path.${e.key}', sb, depth + 1);
      }
    } else if (v is List) {
      sb.writeln('$path: array[${v.length}]');
      if (v.isNotEmpty) _shape(v.first, '$path[0]', sb, depth + 1);
    } else {
      final s = '$v';
      sb.writeln('$path: ${v.runtimeType} = ${s.length > 60 ? '${s.substring(0, 60)}…' : s}');
    }
  }

  // ----------------------------------------------------------- office files

  static String _entry(Archive arc, String name) {
    final f = arc.findFile(name);
    if (f == null) return '';
    return utf8.decode(f.content as List<int>, allowMalformed: true);
  }

  static String _decodeEntities(String s) => s
      .replaceAll('&lt;', '<')
      .replaceAll('&gt;', '>')
      .replaceAll('&quot;', '"')
      .replaceAll('&apos;', "'")
      .replaceAllMapped(RegExp(r'&#(\d+);'), (m) {
        final c = int.tryParse(m.group(1)!);
        return c == null ? '' : String.fromCharCode(c);
      })
      .replaceAll('&amp;', '&');

  static String _docx(Uint8List bytes) {
    final arc = ZipDecoder().decodeBytes(bytes);
    var xml = _entry(arc, 'word/document.xml');
    if (xml.isEmpty) return '[Không tìm thấy nội dung DOCX]';
    xml = xml
        .replaceAll('</w:p>', '\n')
        .replaceAll('</w:tc>', ' | ')
        .replaceAll(RegExp(r'<w:tab\s*/>'), '\t')
        .replaceAll(RegExp(r'<w:br[^>]*/>'), '\n');
    final text = _decodeEntities(xml.replaceAll(RegExp(r'<[^>]+>'), ''));
    return text.replaceAll(RegExp(r'\n{3,}'), '\n\n').trim();
  }

  static String _pptx(Uint8List bytes) {
    final arc = ZipDecoder().decodeBytes(bytes);
    final re = RegExp(r'^ppt/slides/slide(\d+)\.xml$');
    final slides = arc.files.where((f) => f.isFile && re.hasMatch(f.name)).toList()
      ..sort((a, b) => int.parse(re.firstMatch(a.name)!.group(1)!)
          .compareTo(int.parse(re.firstMatch(b.name)!.group(1)!)));
    final sb = StringBuffer('Số slide: ${slides.length}\n');
    for (final s in slides) {
      final n = re.firstMatch(s.name)!.group(1);
      var xml = utf8.decode(s.content as List<int>, allowMalformed: true);
      xml = xml.replaceAll('</a:p>', '\n');
      final text = _decodeEntities(xml.replaceAll(RegExp(r'<[^>]+>'), '')).trim();
      sb.writeln('\n## Slide $n\n$text');
    }
    return sb.toString();
  }

  static int _colIndex(String ref) {
    var n = 0;
    for (final c in ref.codeUnits) {
      if (c >= 65 && c <= 90) {
        n = n * 26 + (c - 64);
      } else if (c >= 97 && c <= 122) {
        n = n * 26 + (c - 96);
      } else {
        break;
      }
    }
    return n - 1;
  }

  static String _xlsx(Uint8List bytes) {
    final arc = ZipDecoder().decodeBytes(bytes);
    final shared = <String>[];
    final ss = _entry(arc, 'xl/sharedStrings.xml');
    for (final m in RegExp(r'<si>([\s\S]*?)</si>').allMatches(ss)) {
      final t = RegExp(r'<t[^>]*>([\s\S]*?)</t>')
          .allMatches(m.group(1)!)
          .map((x) => x.group(1)!)
          .join();
      shared.add(_decodeEntities(t));
    }
    final wb = _entry(arc, 'xl/workbook.xml');
    final names = RegExp(r'<sheet [^>]*name="([^"]*)"')
        .allMatches(wb)
        .map((m) => _decodeEntities(m.group(1)!))
        .toList();
    final re = RegExp(r'^xl/worksheets/sheet(\d+)\.xml$');
    final sheets = arc.files.where((f) => f.isFile && re.hasMatch(f.name)).toList()
      ..sort((a, b) => int.parse(re.firstMatch(a.name)!.group(1)!)
          .compareTo(int.parse(re.firstMatch(b.name)!.group(1)!)));

    final sb = StringBuffer('Số sheet: ${sheets.length}\n');
    var idx = 0;
    for (final sh in sheets) {
      final xml = utf8.decode(sh.content as List<int>, allowMalformed: true);
      final name = idx < names.length ? names[idx] : 'Sheet${idx + 1}';
      idx++;
      final rowMatches = RegExp(r'<row[^>]*>([\s\S]*?)</row>').allMatches(xml).toList();
      sb.writeln('\n## Sheet: $name (${rowMatches.length} dòng có dữ liệu)');
      var shown = 0;
      for (final rm in rowMatches) {
        if (shown >= 500) {
          sb.writeln('[... còn ${rowMatches.length - shown} dòng ...]');
          break;
        }
        final cells = <int, String>{};
        for (final cm in RegExp(r'<c\s([^>]*?)(?:/>|>([\s\S]*?)</c>)').allMatches(rm.group(1)!)) {
          final attrs = cm.group(1) ?? '';
          final inner = cm.group(2) ?? '';
          final ref = RegExp(r'r="([A-Za-z]+)\d+"').firstMatch(attrs)?.group(1);
          if (ref == null) continue;
          final type = RegExp(r'\bt="(\w+)"').firstMatch(attrs)?.group(1);
          String val = '';
          final v = RegExp(r'<v>([\s\S]*?)</v>').firstMatch(inner)?.group(1);
          if (type == 's' && v != null) {
            final i = int.tryParse(v);
            if (i != null && i < shared.length) val = shared[i];
          } else if (type == 'inlineStr') {
            val = _decodeEntities(inner.replaceAll(RegExp(r'<[^>]+>'), ''));
          } else if (v != null) {
            val = _decodeEntities(v);
          }
          final ci = _colIndex(ref);
          if (ci >= 0 && ci < 100) cells[ci] = val;
        }
        if (cells.isEmpty) continue;
        final maxC = cells.keys.reduce(math.max);
        sb.writeln(List.generate(maxC + 1, (i) => cells[i] ?? '').join('\t'));
        shown++;
      }
    }
    return sb.toString();
  }

  // -------------------------------------------------------------------- zip

  static String _zip(Uint8List bytes, int budget) {
    final arc = ZipDecoder().decodeBytes(bytes);
    final files = arc.files.where((f) => f.isFile).toList();
    final sb = StringBuffer('Số tệp: ${files.length}\n\nCây thư mục (tối đa 300 mục):\n');
    for (final f in files.take(300)) {
      sb.writeln('  ${f.name} (${Attachment.formatBytes(f.size)})');
    }
    if (files.length > 300) sb.writeln('  ... còn ${files.length - 300} tệp nữa');

    final skip = RegExp(r'(node_modules/|\.git/|/build/|^build/|\.dart_tool/|\.lock$|\.min\.(js|css)$|\.(png|jpg|jpeg|gif|webp|ico|jar|so|class|apk|aab|ttf|otf|woff2?|mp4|mp3|pdf|zip)$)',
        caseSensitive: false);
    int prio(String n) {
      final base = n.split('/').last.toLowerCase();
      if (base.startsWith('readme') ||
          const {
            'pubspec.yaml', 'package.json', 'build.gradle', 'pom.xml', 'requirements.txt',
            'go.mod', 'cargo.toml', 'androidmanifest.xml', 'settings.gradle', 'pyproject.toml',
          }.contains(base)) {
        return 0;
      }
      if (RegExp(r'^(main|index|app)\.').hasMatch(base)) return 1;
      if (RegExp(r'(^|/)(lib|src)/').hasMatch(n)) return 2;
      return 3;
    }

    bool isText(String n) {
      final i = n.lastIndexOf('.');
      final e = i < 0 ? n.split('/').last.toLowerCase() : n.substring(i + 1).toLowerCase();
      return _textExts.contains(e);
    }

    final cand = files
        .where((f) => isText(f.name) && f.size <= 400 * 1024 && !skip.hasMatch(f.name))
        .toList()
      ..sort((a, b) {
        final p = prio(a.name).compareTo(prio(b.name));
        return p != 0 ? p : a.size.compareTo(b.size);
      });

    var left = budget - sb.length;
    var included = 0;
    for (final c in cand) {
      if (left < 800) break;
      var text = utf8.decode(c.content as List<int>, allowMalformed: true);
      final cap = math.min(left - 100, 25000);
      if (text.length > cap) text = '${text.substring(0, cap)}\n[... cắt ...]';
      sb.writeln('\n--- ${c.name} ---\n$text');
      left -= text.length + c.name.length + 10;
      included++;
    }
    sb.writeln('\n[Đã đưa nội dung $included/${cand.length} tệp văn bản/code; các tệp còn lại chỉ có trong cây thư mục]');
    return sb.toString();
  }

  // -------------------------------------------------------------------- pdf

  static String _pdfText(Uint8List b, int budget) {
    final s = latin1.decode(b, allowInvalid: true);
    final pages = RegExp(r'/Type\s*/Page[^s]').allMatches(s).length;
    final out = StringBuffer();
    var pos = 0;
    while (true) {
      final i = s.indexOf('stream', pos);
      if (i < 0) break;
      var start = i + 6;
      if (s.startsWith('\r\n', start)) {
        start += 2;
      } else if (s.startsWith('\n', start)) {
        start += 1;
      } else {
        pos = i + 6;
        continue;
      }
      final end = s.indexOf('endstream', start);
      if (end < 0) break;
      pos = end + 9;
      List<int> raw;
      try {
        raw = zlib.decode(b.sublist(start, end));
      } catch (_) {
        raw = b.sublist(start, end);
      }
      final txt = latin1.decode(raw, allowInvalid: true);
      if (!txt.contains('BT')) continue;
      for (final blk in RegExp(r'BT([\s\S]*?)ET').allMatches(txt)) {
        final line = StringBuffer();
        for (final m in RegExp(r'\[((?:[^\]\\]|\\.)*)\]\s*TJ|\(((?:\\.|[^\\)])*)\)\s*Tj')
            .allMatches(blk.group(1)!)) {
          final arr = m.group(1);
          if (arr != null) {
            for (final sm in RegExp(r'\(((?:\\.|[^\\)])*)\)').allMatches(arr)) {
              line.write(_unescapePdf(sm.group(1)!));
            }
          } else {
            line.write(_unescapePdf(m.group(2) ?? ''));
          }
          line.write(' ');
        }
        final t = line.toString().trim();
        if (t.isNotEmpty) out.writeln(t);
      }
      if (out.length > budget * 2) break;
    }
    final text = out.toString().replaceAll(RegExp(r'[^\S\n]+'), ' ').trim();
    final letters = RegExp(r'[A-Za-zÀ-ỹ]').allMatches(text).length;
    if (text.length < 50 || letters < text.length * 0.4) {
      return 'Số trang ≈ $pages\n[Không trích được văn bản đáng tin cậy (PDF dạng ảnh scan hoặc font mã hóa đặc biệt). '
          'Hãy dùng Claude để đọc PDF trực tiếp, hoặc gửi ảnh chụp từng trang.]';
    }
    return 'Số trang ≈ $pages (trích văn bản cơ bản, có thể mất định dạng/bảng)\n${_clip(text, budget)}';
  }

  static String _unescapePdf(String s) {
    final sb = StringBuffer();
    for (var i = 0; i < s.length; i++) {
      final c = s[i];
      if (c != '\\' || i + 1 >= s.length) {
        sb.write(c);
        continue;
      }
      final n = s[++i];
      switch (n) {
        case 'n':
          sb.write('\n');
          break;
        case 'r':
          break;
        case 't':
          sb.write('\t');
          break;
        case '(':
        case ')':
        case '\\':
          sb.write(n);
          break;
        default:
          if (RegExp(r'[0-7]').hasMatch(n)) {
            var oct = n;
            while (oct.length < 3 && i + 1 < s.length && RegExp(r'[0-7]').hasMatch(s[i + 1])) {
              oct += s[++i];
            }
            sb.writeCharCode(int.parse(oct, radix: 8));
          } else {
            sb.write(n);
          }
      }
    }
    return sb.toString();
  }

  // ----------------------------------------------------------------- binary

  static Future<String> _binary(File file, int size) async {
    final head = await _readBytes(file, 0, 48);
    final hex = head.map((b) => b.toRadixString(16).padLeft(2, '0')).join(' ');
    final sample = await _readBytes(file, 0, 2 * 1024 * 1024);
    final strings = <String>[];
    final cur = StringBuffer();
    for (final b in sample) {
      if (b >= 32 && b < 127) {
        cur.writeCharCode(b);
      } else {
        if (cur.length >= 6) strings.add(cur.toString());
        cur.clear();
        if (strings.length >= 60) break;
      }
    }
    final sb = StringBuffer('[Tệp nhị phân, không đọc được dạng văn bản]\n');
    sb.writeln('48 byte đầu (hex): $hex');
    if (strings.isNotEmpty) {
      sb.writeln('Chuỗi đọc được trong 2MB đầu:');
      sb.writeln(strings.map((e) => e.length > 120 ? e.substring(0, 120) : e).join('\n'));
    }
    return sb.toString();
  }

  // ---------------------------------------------------------------- helpers

  /// Giữ phần đầu + cuối khi vượt ngân sách ký tự.
  static String _clip(String s, int budget) {
    if (s.length <= budget) return s;
    final h = (budget * 0.7).toInt();
    final t = (budget * 0.25).toInt();
    return '${s.substring(0, h)}\n\n[... đã lược ${s.length - h - t} ký tự ở giữa để vừa ngữ cảnh ...]\n\n${s.substring(s.length - t)}';
  }
}

class _Col {
  int filled = 0;
  int nums = 0;
  double min = double.infinity;
  double max = -double.infinity;
  double sum = 0;
  final Set<String> distinct = {};
  bool overflow = false;

  void add(String v) {
    final s = v.trim();
    if (s.isEmpty) return;
    filled++;
    final n = double.tryParse(s);
    if (n != null) {
      nums++;
      if (n < min) min = n;
      if (n > max) max = n;
      sum += n;
    }
    if (distinct.length < 12) {
      distinct.add(s.length > 40 ? s.substring(0, 40) : s);
    } else if (!distinct.contains(s)) {
      overflow = true;
    }
  }

  String describe(int rows) {
    if (filled == 0) return 'trống';
    final empty = rows - filled;
    final emptyNote = empty > 0 ? ', thiếu $empty' : '';
    if (nums >= filled * 0.9) {
      String f(double d) => d == d.roundToDouble() ? d.toInt().toString() : d.toStringAsFixed(3);
      return 'số: min ${f(min)}, max ${f(max)}, TB ${f(sum / nums)}$emptyNote';
    }
    if (!overflow) return 'phân loại: ${distinct.join(', ')}$emptyNote';
    return 'văn bản, nhiều giá trị khác nhau (vd: ${distinct.take(4).join(', ')})$emptyNote';
  }
}
