import 'dart:io';

enum AttachmentKind { image, video, document }

class Attachment {
  final String path;
  final String name;
  final int size;
  final AttachmentKind kind;

  /// PDF được gửi trực tiếp cho model (Claude đọc được cả hình/bảng).
  final bool nativePdf;

  const Attachment({
    required this.path,
    required this.name,
    required this.size,
    required this.kind,
    this.nativePdf = false,
  });

  static const imageExts = {'jpg', 'jpeg', 'png', 'gif', 'webp'};
  static const videoExts = {'mp4', 'mov', 'mkv', 'avi', 'webm', '3gp', 'm4v'};

  static Future<Attachment> fromPath(String path) async {
    final name = path.split(RegExp(r'[\\/]')).last;
    final size = await File(path).length();
    final i = name.lastIndexOf('.');
    final ext = i < 0 ? '' : name.substring(i + 1).toLowerCase();
    final kind = imageExts.contains(ext)
        ? AttachmentKind.image
        : (videoExts.contains(ext) ? AttachmentKind.video : AttachmentKind.document);
    return Attachment(path: path, name: name, size: size, kind: kind);
  }

  String get ext {
    final i = name.lastIndexOf('.');
    return i < 0 ? '' : name.substring(i + 1).toLowerCase();
  }

  String get sizeLabel => formatBytes(size);

  static String formatBytes(int b) {
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    var v = b.toDouble();
    var i = 0;
    while (v >= 1024 && i < units.length - 1) {
      v /= 1024;
      i++;
    }
    return i == 0 ? '$b B' : '${v.toStringAsFixed(1)} ${units[i]}';
  }

  Attachment copyWith({bool? nativePdf}) => Attachment(
        path: path,
        name: name,
        size: size,
        kind: kind,
        nativePdf: nativePdf ?? this.nativePdf,
      );

  Map<String, dynamic> toJson() => {
        'path': path,
        'name': name,
        'size': size,
        'kind': kind.name,
        'nativePdf': nativePdf,
      };

  factory Attachment.fromJson(Map<String, dynamic> j) => Attachment(
        path: j['path'] as String,
        name: j['name'] as String,
        size: (j['size'] as num?)?.toInt() ?? 0,
        kind: AttachmentKind.values.firstWhere(
          (e) => e.name == j['kind'],
          orElse: () => AttachmentKind.document,
        ),
        nativePdf: j['nativePdf'] == true,
      );
}
