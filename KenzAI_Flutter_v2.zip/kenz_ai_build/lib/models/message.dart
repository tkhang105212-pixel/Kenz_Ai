import 'attachment.dart';

enum MessageRole { user, assistant }

class ChatMessage {
  final String id;
  final MessageRole role;
  final String content;
  final List<Attachment> attachments;

  /// Nội dung tệp đã trích xuất (ẩn khỏi UI, luôn gửi kèm lịch sử cho model).
  final String? fileContext;
  final DateTime timestamp;
  final bool isLoading;
  final bool isError;
  final String? model;

  ChatMessage({
    required this.id,
    required this.role,
    required this.content,
    this.attachments = const [],
    this.fileContext,
    DateTime? timestamp,
    this.isLoading = false,
    this.isError = false,
    this.model,
  }) : timestamp = timestamp ?? DateTime.now();

  ChatMessage copyWith({
    String? content,
    bool? isLoading,
    bool? isError,
    String? model,
  }) {
    return ChatMessage(
      id: id,
      role: role,
      content: content ?? this.content,
      attachments: attachments,
      fileContext: fileContext,
      timestamp: timestamp,
      isLoading: isLoading ?? this.isLoading,
      isError: isError ?? this.isError,
      model: model ?? this.model,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'role': role.name,
        'content': content,
        'attachments': attachments.map((a) => a.toJson()).toList(),
        'fileContext': fileContext,
        'timestamp': timestamp.toIso8601String(),
        'isError': isError,
        'model': model,
      };

  factory ChatMessage.fromJson(Map<String, dynamic> j) {
    final atts = (j['attachments'] as List?) ?? const [];
    return ChatMessage(
      id: j['id'] as String,
      role: MessageRole.values.firstWhere(
        (e) => e.name == j['role'],
        orElse: () => MessageRole.assistant,
      ),
      content: (j['content'] as String?) ?? '',
      attachments: atts
          .map((e) => Attachment.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      fileContext: j['fileContext'] as String?,
      timestamp: DateTime.tryParse((j['timestamp'] as String?) ?? ''),
      isError: j['isError'] == true,
      model: j['model'] as String?,
    );
  }
}
