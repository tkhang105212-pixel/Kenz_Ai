import 'package:flutter/material.dart';
import '../utils/theme.dart';

class InputBar extends StatelessWidget {
  final TextEditingController controller;
  final bool busy;
  final VoidCallback onSend;
  final VoidCallback onStop;
  final VoidCallback onPickImages;
  final VoidCallback onTakePhoto;
  final VoidCallback onPickVideo;
  final VoidCallback onPickFiles;

  const InputBar({
    super.key,
    required this.controller,
    required this.busy,
    required this.onSend,
    required this.onStop,
    required this.onPickImages,
    required this.onTakePhoto,
    required this.onPickVideo,
    required this.onPickFiles,
  });

  PopupMenuItem<String> _item(String v, IconData icon, String label) {
    return PopupMenuItem(
      value: v,
      child: Row(
        children: [
          Icon(icon, color: KenzTheme.neonBlue, size: 22),
          const SizedBox(width: 12),
          Text(label, style: const TextStyle(color: KenzTheme.textPrimary)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        left: 8,
        right: 8,
        top: 8,
        bottom: MediaQuery.of(context).padding.bottom + 8,
      ),
      decoration: const BoxDecoration(
        color: KenzTheme.darkBg,
        border: Border(top: BorderSide(color: Color(0xFF1E3A5F), width: 1)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.add_circle_outline, color: KenzTheme.neonBlue, size: 28),
            color: KenzTheme.cardBg,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            onSelected: (v) {
              if (v == 'file') onPickFiles();
              if (v == 'gallery') onPickImages();
              if (v == 'camera') onTakePhoto();
              if (v == 'video') onPickVideo();
            },
            itemBuilder: (_) => [
              _item('file', Icons.attach_file, 'Tệp (code, PDF, Word, Excel, ZIP, log...)'),
              _item('gallery', Icons.photo_library, 'Chọn ảnh'),
              _item('camera', Icons.camera_alt, 'Chụp ảnh'),
              _item('video', Icons.videocam, 'Chọn video'),
            ],
          ),
          Expanded(
            child: TextField(
              controller: controller,
              style: const TextStyle(color: KenzTheme.textPrimary, fontSize: 15),
              maxLines: 6,
              minLines: 1,
              textInputAction: TextInputAction.newline,
              decoration: const InputDecoration(
                hintText: 'Nhập câu hỏi, yêu cầu code hoặc đính kèm tệp...',
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              ),
            ),
          ),
          const SizedBox(width: 4),
          GestureDetector(
            onTap: busy ? onStop : onSend,
            child: Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                gradient: busy
                    ? null
                    : const LinearGradient(colors: [KenzTheme.primaryBlue, KenzTheme.neonBlue]),
                color: busy ? Colors.redAccent.withOpacity(0.85) : null,
                shape: BoxShape.circle,
              ),
              child: Icon(
                busy ? Icons.stop_rounded : Icons.send_rounded,
                color: busy ? Colors.white : Colors.black,
                size: 24,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
