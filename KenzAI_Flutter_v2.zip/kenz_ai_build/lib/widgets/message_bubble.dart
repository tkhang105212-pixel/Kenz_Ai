import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import '../models/attachment.dart';
import '../models/message.dart';
import '../utils/theme.dart';

class _Seg {
  final bool isCode;
  final String lang;
  final String text;
  const _Seg(this.isCode, this.lang, this.text);
}

/// Tách nội dung thành đoạn markdown và code block (chịu được code block chưa đóng khi đang stream).
List<_Seg> _split(String s) {
  final segs = <_Seg>[];
  final re = RegExp(r'```([^\n`]*)\n([\s\S]*?)(```|$)');
  var last = 0;
  for (final m in re.allMatches(s)) {
    if (m.start > last) segs.add(_Seg(false, '', s.substring(last, m.start)));
    segs.add(_Seg(true, (m.group(1) ?? '').trim(), (m.group(2) ?? '').trimRight()));
    last = m.end;
  }
  if (last < s.length) segs.add(_Seg(false, '', s.substring(last)));
  return segs;
}

class MessageBubble extends StatelessWidget {
  final ChatMessage message;
  final VoidCallback? onRetry;

  const MessageBubble({super.key, required this.message, this.onRetry});

  void _copy(BuildContext context, String text) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Đã copy!'),
        duration: Duration(seconds: 1),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Widget _attachments() {
    final imgs = message.attachments.where((a) => a.kind == AttachmentKind.image).toList();
    final others = message.attachments.where((a) => a.kind != AttachmentKind.image).toList();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (imgs.isNotEmpty)
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              for (final a in imgs)
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image.file(
                    File(a.path),
                    width: imgs.length == 1 ? 220 : 100,
                    height: imgs.length == 1 ? null : 100,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      width: 100,
                      height: 100,
                      color: KenzTheme.surfaceBg,
                      child: const Icon(Icons.broken_image, color: KenzTheme.textSecondary),
                    ),
                  ),
                ),
            ],
          ),
        if (others.isNotEmpty) ...[
          if (imgs.isNotEmpty) const SizedBox(height: 6),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              for (final a in others)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                  decoration: BoxDecoration(
                    color: KenzTheme.surfaceBg,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        a.kind == AttachmentKind.video ? Icons.videocam : Icons.description_outlined,
                        size: 16,
                        color: KenzTheme.neonBlue,
                      ),
                      const SizedBox(width: 6),
                      Flexible(
                        child: Text(
                          '${a.name} · ${a.sizeLabel}',
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: KenzTheme.textPrimary, fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ],
        const SizedBox(height: 8),
      ],
    );
  }

  MarkdownStyleSheet get _md => MarkdownStyleSheet(
        p: const TextStyle(color: KenzTheme.textPrimary, fontSize: 15, height: 1.4),
        code: const TextStyle(
          backgroundColor: KenzTheme.surfaceBg,
          color: KenzTheme.neonBlue,
          fontFamily: 'monospace',
          fontSize: 13,
        ),
        h1: const TextStyle(color: KenzTheme.neonBlue, fontSize: 20),
        h2: const TextStyle(color: KenzTheme.neonBlue, fontSize: 18),
        h3: const TextStyle(color: KenzTheme.primaryBlue, fontSize: 16),
        listBullet: const TextStyle(color: KenzTheme.neonBlue),
        strong: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        tableBorder: TableBorder.all(color: const Color(0xFF1E3A5F)),
        tableBody: const TextStyle(color: KenzTheme.textPrimary, fontSize: 13),
        tableHead: const TextStyle(color: KenzTheme.neonBlue, fontSize: 13, fontWeight: FontWeight.bold),
      );

  Widget _codeBlock(BuildContext context, _Seg seg) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF0D0D1F),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFF1E3A5F)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.only(left: 12, right: 4),
            decoration: const BoxDecoration(
              color: Color(0xFF14142E),
              borderRadius: BorderRadius.vertical(top: Radius.circular(8)),
            ),
            child: Row(
              children: [
                Text(
                  seg.lang.isEmpty ? 'code' : seg.lang,
                  style: const TextStyle(color: KenzTheme.textSecondary, fontSize: 12),
                ),
                const Spacer(),
                IconButton(
                  visualDensity: VisualDensity.compact,
                  icon: const Icon(Icons.copy, size: 15, color: KenzTheme.textSecondary),
                  tooltip: 'Copy code',
                  onPressed: () => _copy(context, seg.text),
                ),
              ],
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.all(12),
            child: SelectableText(
              seg.text,
              style: const TextStyle(
                color: KenzTheme.textPrimary,
                fontFamily: 'monospace',
                fontSize: 12.5,
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _content(BuildContext context) {
    if (message.isLoading && message.content.isEmpty) {
      return const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 16,
            height: 16,
            child: CircularProgressIndicator(strokeWidth: 2, color: KenzTheme.neonBlue),
          ),
          SizedBox(width: 10),
          Text('Đang suy nghĩ...', style: TextStyle(color: KenzTheme.textSecondary, fontSize: 14)),
        ],
      );
    }
    final segs = _split(message.content);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (final seg in segs)
          if (seg.isCode)
            _codeBlock(context, seg)
          else if (seg.text.trim().isNotEmpty)
            MarkdownBody(data: seg.text, selectable: true, styleSheet: _md),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final isUser = message.role == MessageRole.user;
    final maxW = MediaQuery.of(context).size.width * (isUser ? 0.78 : 0.86);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!isUser) ...[
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Image.asset('assets/images/kenz_avatar.png', width: 32, height: 32, fit: BoxFit.cover),
            ),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Container(
              constraints: BoxConstraints(maxWidth: maxW),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: isUser
                    ? KenzTheme.primaryBlue.withOpacity(0.25)
                    : (message.isError ? const Color(0xFF2A1218) : KenzTheme.cardBg),
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(16),
                  topRight: const Radius.circular(16),
                  bottomLeft: Radius.circular(isUser ? 16 : 4),
                  bottomRight: Radius.circular(isUser ? 4 : 16),
                ),
                border: Border.all(
                  color: message.isError
                      ? Colors.redAccent.withOpacity(0.5)
                      : (isUser ? KenzTheme.primaryBlue.withOpacity(0.4) : const Color(0xFF1E3A5F)),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (message.attachments.isNotEmpty) _attachments(),
                  _content(context),
                  if (!isUser && !message.isLoading)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Row(
                        children: [
                          if (message.model != null && !message.isError)
                            Expanded(
                              child: Text(
                                message.model!,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(color: KenzTheme.textSecondary, fontSize: 11),
                              ),
                            )
                          else
                            const Spacer(),
                          if (message.isError && onRetry != null)
                            TextButton.icon(
                              onPressed: onRetry,
                              icon: const Icon(Icons.refresh, size: 16),
                              label: const Text('Thử lại'),
                            )
                          else
                            IconButton(
                              icon: const Icon(Icons.copy, size: 16, color: KenzTheme.textSecondary),
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(),
                              onPressed: () => _copy(context, message.content),
                            ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
          if (isUser) const SizedBox(width: 8),
        ],
      ),
    );
  }
}
