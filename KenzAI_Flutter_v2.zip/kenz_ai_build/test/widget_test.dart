import 'package:flutter_test/flutter_test.dart';
import 'package:kenz_ai/main.dart';

void main() {
  testWidgets('App khởi động được', (WidgetTester tester) async {
    await tester.pumpWidget(const KenzAIApp());
    expect(find.byType(KenzAIApp), findsOneWidget);
  });
}
