package com.kenzai.kenz_ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
