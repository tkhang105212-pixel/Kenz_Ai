#!/usr/bin/env bash
# Build APK cho Kenz AI. Dùng: ./build_apk.sh [debug|release|split]
set -e
cd "$(dirname "$0")"

MODE="${1:-release}"

command -v flutter >/dev/null || { echo "Chưa có flutter trong PATH"; exit 1; }
command -v java >/dev/null || { echo "Chưa cài JDK 17"; exit 1; }

# Nếu chưa có ANDROID_HOME/ANDROID_SDK_ROOT thì để flutter tự dò
if [ -n "$ANDROID_HOME" ]; then flutter config --android-sdk "$ANDROID_HOME" >/dev/null; fi
yes | flutter doctor --android-licenses >/dev/null 2>&1 || true

flutter pub get
case "$MODE" in
  debug)   flutter build apk --debug ;;
  split)   flutter build apk --release --split-per-abi ;;
  *)       flutter build apk --release ;;
esac

echo
echo "APK nằm ở: build/app/outputs/flutter-apk/"
ls -1 build/app/outputs/flutter-apk/*.apk
